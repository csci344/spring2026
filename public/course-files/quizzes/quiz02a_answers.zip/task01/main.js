// your function here
document.querySelector("button").addEventListener("click", () => {
    document.querySelector("body").classList.toggle("dark-mode");
});
