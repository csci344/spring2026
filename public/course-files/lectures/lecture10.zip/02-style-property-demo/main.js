
const makeRed = () => {
    // your code here...
    console.log('Change background to red');
    document.querySelector('body').style.backgroundColor = 'red';
};

const makeBlue = () => {
    // your code here...
    console.log('Change background to blue');
};

const makePink = () => {
    // your code here...
    console.log('Change background to pink');
};

const makeOrange = () => {
    // your code here...
    console.log('Change background to orange');
};

