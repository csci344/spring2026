function addCat() {
    // your code here...
}

function addDog() {
    // your code here...
}
